
import java.util.LinkedList;


public class Node {
	boolean sClasse;
	int cont;
	int nivel;
	String atributo;
	String valor;
	LinkedList<Node> filhos;
	
	public Node(){
		int nivel = cont = 0;
		atributo = null;
		filhos = new LinkedList<Node>();
		valor = null;
		sClasse = false;
	}

	public Node(int nivel, String atributo, LinkedList<Node> filhos, String valor) {
		super();
		this.nivel = nivel;
		this.atributo = atributo;
		this.filhos = filhos;
		this.valor = valor;
		cont = 0;
		sClasse = false;
	}

	public Node(Node n){
		super();
		this.setnivel(n.getnivel());
		this.setatributo(n.getatributo());
		this.setfilhos(n.getfilhos());
		this.setvalor(n.getvalor());
		this.setcont(n.getcont());
		this.setsClasse(n.sClasse());
	}

	public Node(int nivel, String atributo, String valor, int cont, boolean sClasse) {
		super();
		this.nivel = nivel;
		this.atributo = atributo;
		this.filhos = new LinkedList<Node>();
		this.valor = valor;
		this.cont = cont;
		this.sClasse = sClasse;
	}

	public String getatributo() {
		return atributo;
	}

	public void setatributo(String atributo) {
		this.atributo = atributo;
	}

	public void setcont(int cont){
		this.cont = cont;
	}

	public int getcont(){
		return cont;
	}
	
	public LinkedList<Node> getfilhos() {
		return filhos;
	}

	public void setfilhos(LinkedList<Node> filhos) {
		this.filhos = new LinkedList<Node>(filhos);
	}

	public String getvalor(){
		return valor;
	}

	public void setvalor(String valor){
		this.valor = valor; 
	}
	
	public int getnivel() {
		return nivel;
	}

	public void setnivel(int nivel) {
		this.nivel = nivel;
	}

	public void setsClasse(boolean sClasse){
		this.sClasse = sClasse;
	}

	public boolean sClasse(){
		return sClasse;
	}
}
