import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;

public class Arvore extends Node{

	 static int Linhas;
   static int class_i;
   static HashMap<String,Node> arvoreDec = new HashMap<String,Node>();
   static LinkedList<String> attrib_glob = new LinkedList<String>();

    public static void main(String args[]) throws IOException {
		Scanner stdin = new Scanner(System.in);
		System.out.println();
		System.out.println("********************Arvores De Decisao********************");
		System.out.println();
		System.out.println("Escolha o formato desejado:");
		System.out.println("  (1) Imprime a arvore de decisao;");
		System.out.println("  (2) Imprime as classes;");
		System.out.println();

		System.out.print("Formato: ");
		int nform = stdin.nextInt();

		System.out.print("Ficheiro: ");

		String ficheiro = stdin.next();
		System.out.println("");

		LinkedList<String> list = ler(ficheiro);

		get_atributos(list);
		class_i = attrib_glob.size()-1;

		String[][] tab_valor = obter_valores(list);

		LinkedList<Integer> linhas_exemplo = new LinkedList<Integer>();
		for(int i = 0; i < Linhas; i++)
			linhas_exemplo.addLast(i);


		LinkedList<String> lista_de_atributos = new LinkedList<String>(attrib_glob);

		lista_de_atributos.removeFirst();
		lista_de_atributos.removeLast();

		Node raiz_arvore = new Node();
		raiz_arvore = ID3_algoritmo(lista_de_atributos, tab_valor, linhas_exemplo,null,0,null,0);

		if(nform == 1) {
			imprimir_arvoreDec(raiz_arvore);
		}
		else {
			System.out.print("Examplo ficheiro: ");
			String ficheiro2 = stdin.next();

			list = new LinkedList<String>();
			list = ler(ficheiro2);
			list.removeFirst();
			String[][] valors_ex = obter_valores(list);

			System.out.println();
			imprimir_Classes(valors_ex,raiz_arvore);
		}
		stdin.close();
    }

    public static Node ID3_algoritmo(LinkedList<String> lista_de_atributos, String[][] tab_valor, LinkedList<Integer> linhas_exemplo,String father, int nivel, String defvalor,int defcont){

		if(linhas_exemplo.isEmpty()){

			return new Node(nivel-1,father,defvalor,defcont,true);
		}

		else if(isequal_de_classe(linhas_exemplo,tab_valor)){

			String valor_classe = tab_valor[linhas_exemplo.getFirst()][class_i];
			int conta_classe = contaClasses(linhas_exemplo,tab_valor,valor_classe);
			return new Node(nivel-1,father,valor_classe,conta_classe,true);

		}

		else if(lista_de_atributos.isEmpty()){

			String valor_classe = maiorClasse(linhas_exemplo,tab_valor);
			int conta_classe = contaClasses(linhas_exemplo,tab_valor,valor_classe);
			return new Node(nivel-1,father,valor_classe,conta_classe,true);
		}

		else {
	   	  String M_Atrib = getMinEntrop(lista_de_atributos,tab_valor,linhas_exemplo);
	    	int atribIndex = attrib_glob.indexOf(M_Atrib);

	    	LinkedList<Node> filhos = new LinkedList<Node>();
	   		Node node = new Node(nivel,M_Atrib,filhos,father);
	    	lista_de_atributos.remove(M_Atrib);

	    	LinkedList<String> attribVal = get_ValD(tab_valor,linhas_exemplo,atribIndex);

	   		for(String currentvalor: attribVal){
	   			LinkedList<Integer> valorEx = getEx(tab_valor,currentvalor, linhas_exemplo, atribIndex);

	   			String major_valor = maiorClasse(linhas_exemplo,tab_valor);

	   			int major_conter = contaClasses(linhas_exemplo,tab_valor,major_valor);
	   			filhos.add(ID3_algoritmo(lista_de_atributos,tab_valor,valorEx,currentvalor,nivel+1,major_valor,major_conter));
    		}
	    	node.setfilhos(filhos);
	     	return node;
		}
    }


    public static int contaClasses(LinkedList<Integer> linhas_exemplo, String[][] tab_valor, String desiredClass){
    	int cont = 0;
    	for(int i = 0;i < Linhas;i++)
    		if(linhas_exemplo.contains(i) && tab_valor[i][class_i].equals(desiredClass))
    			cont++;
    	return cont;
    }


    public static String maiorClasse(LinkedList<Integer> linhas_exemplo, String[][] tab_valor){
    	int maxvalor = Integer.MIN_VALUE;
    	String maior_class = null;
		HashMap<String, Integer> contaClasses = new HashMap<String,Integer>();

		for(int i = 0; i < Linhas; i++){
	    	if(linhas_exemplo.contains(i)){
	    		if(!contaClasses.containsKey(tab_valor[i][class_i]))
					contaClasses.put(tab_valor[i][class_i], 1);
	    		else if(contaClasses.containsKey(tab_valor[i][class_i])){
					int aux = contaClasses.get(tab_valor[i][class_i]);
					contaClasses.put(tab_valor[i][class_i], aux+1);
	    		}
			}
		}



		for(int i = 0; i < Linhas; i++)
			if(linhas_exemplo.contains(i) && contaClasses.get(tab_valor[i][class_i]) > maxvalor){
				maxvalor = contaClasses.get(tab_valor[i][class_i]);
				maior_class = tab_valor[i][class_i];
			}
		return maior_class;
    }


    public static LinkedList<Integer> getEx(String[][] tab_valor, String des_val, LinkedList<Integer> linhas_exemplo, int atribIndex){
    	LinkedList<Integer> valorEx = new LinkedList<Integer>();
    	for(int i = 0; i < Linhas; i++)
    		if(linhas_exemplo.contains(i) && tab_valor[i][atribIndex].equals(des_val))
    			valorEx.add(i);
    	return valorEx;
    }



    public static boolean isequal_de_classe(LinkedList<Integer> linhas_exemplo, String[][] tab_valor){
    	String previousClass = tab_valor[linhas_exemplo.getFirst()][class_i];
    	for(int i = 0; i < Linhas; i++){
    		if(linhas_exemplo.contains(i) && !previousClass.equals(tab_valor[i][class_i]))
    			return false;
    	}
    	return true;
    }


    public static void get_atributos(LinkedList<String> list) {
		String linha = list.removeFirst();
		String[] split = linha.split(",");
		for(String atributo: split)
			attrib_glob.addLast(atributo);
	}


    public static LinkedList<String> get_ValD(String[][] tab_valor, LinkedList<Integer> linhas_exemplo,int atribIndex){
    	LinkedList<String> attribVal = new LinkedList<String>();
    	for(int i = 0; i < Linhas; i++)
    		if(linhas_exemplo.contains(i) && !attribVal.contains(tab_valor[i][atribIndex]))
    			attribVal.add(tab_valor[i][atribIndex]);
    	return attribVal;
    }


    public static LinkedList<String> ler(String ficheiro) {
		LinkedList<String> list = new LinkedList<String>();
		BufferedReader buffer = null;
		try {
	    	String linha;
	    	buffer = new BufferedReader(new FileReader(ficheiro));
	    	while ((linha = (buffer.readLine())) != null)
			list.addLast(linha);
		} catch (IOException e) {
	    	e.printStackTrace();
		} finally {
	    	try {
			if (buffer != null)
		    	buffer.close();
	    	} catch (IOException e) {
			e.printStackTrace();
	    	}
		}
		return list;
    }



    public static String[][] obter_valores(LinkedList<String> list){

		int i = 0;
		int j = 0;

		String linha = list.removeFirst();
		String[] split = linha.split(",");
		String[][] tab_valor = new String[list.size()+1][split.length];
		Linhas = list.size()+1;
		split = linha.split(",");
		for(String valor:split){
	    	tab_valor[i][j]=valor;
	    	j++;
		}
		while(!list.isEmpty()){
	    	i++;
	    	j=0;
	    	linha = list.removeFirst();
	    	split = linha.split(",");
	    	for(String valor:split){
				tab_valor[i][j]=valor;
				j++;
		    }
		}
	return tab_valor;
    }



    public static double getEntropia(String[][] tab_valor, String des_val, int atribIndex, LinkedList<Integer> linhas_exemplo){

		HashMap<String, Integer> classvalors = new HashMap<String,Integer>();
		int totaldes_val=0;
		for(int i = 0; i < Linhas; i++){
	 	    if(linhas_exemplo.contains(i)){
	    		if(!classvalors.containsKey(tab_valor[i][class_i]) && tab_valor[i][atribIndex].equals(des_val)){
					classvalors.put(tab_valor[i][class_i], 1);
					totaldes_val++;
	    		}
	    		else if(classvalors.containsKey(tab_valor[i][class_i]) && tab_valor[i][atribIndex].equals(des_val)){
					int aux = classvalors.get(tab_valor[i][class_i]);
					classvalors.put(tab_valor[i][class_i], aux + 1);
					totaldes_val++;
	    		}
			}
		}

		LinkedList<String> verifiedClassVal = new LinkedList<String>();
		double entropiaVal = 0;


		for(int i = 0; i < Linhas; i++)
			if(linhas_exemplo.contains(i))
		    	if(tab_valor[i][atribIndex].equals(des_val) && !verifiedClassVal.contains(tab_valor[i][class_i])){
					verifiedClassVal.add(tab_valor[i][class_i]);

					double prob = (double) classvalors.get(tab_valor[i][class_i])/totaldes_val;
					entropiaVal -= (double) prob*(Math.log(prob)/Math.log(2));
		    	}
		return entropiaVal;
    }


    public static String getMinEntrop(LinkedList<String> lista_de_atributos, String[][] tab_valor, LinkedList<Integer> linhas_exemplo){
		String M_Atrib = new String();
		double minVal = (double) Integer.MAX_VALUE;
		for(String atributo: lista_de_atributos){
	    	int atribIndex = attrib_glob.indexOf(atributo);
	    	LinkedList<String> checkValors = new LinkedList<String>();
	    	double entropiaVal = (double) 0;
	    	for(int i = 0; i < Linhas; i++){

					if(linhas_exemplo.contains(i) && !checkValors.contains(tab_valor[i][atribIndex])){
						checkValors.add(tab_valor[i][atribIndex]);
						double prob = get_Probabilidade(tab_valor[i][atribIndex],atribIndex,linhas_exemplo,tab_valor);
						entropiaVal += (double) prob*getEntropia(tab_valor, tab_valor[i][atribIndex], atribIndex, linhas_exemplo);
					}
			}
			if(minVal > entropiaVal){
				minVal = entropiaVal;
				M_Atrib = atributo;
			}
		}
		return M_Atrib;
    }



  	public static double get_Probabilidade(String des_val, int atribIndex, LinkedList<Integer> linhas_exemplo, String[][] tab_valor){
  		int x = 0;
  		for(int i = 0; i < Linhas; i++)
  			if(tab_valor[i][atribIndex].equals(des_val) && linhas_exemplo.contains(i))
  				x++;
  		return (double) x/linhas_exemplo.size();
  	}



  	public static void imprimir_arvoreDec(Node node){

  		LinkedList<Node> filhos=node.getfilhos();

  		if(!node.sClasse()){
  			if (node.getvalor() != null){
  				for(int i = 0; i < node.getnivel();i++)
  					System.out.print("      ");
   					System.out.println(node.getvalor()+": ");}
   			if(node.getvalor()!=null)
   				for(int i = 0; i < node.getnivel()+1; i++)
  					System.out.print("     ");
  			System.out.println(node.getatributo());

  	  		while(!filhos.isEmpty())
  	  			imprimir_arvoreDec(filhos.remove());
  		}

  		else{
  			for(int i = 0; i < node.getnivel()+1; i++)
  				System.out.print("      ");
  			System.out.println(node.getatributo()+": "+node.getvalor()+" ("+node.getcont()+")");
   		}
  	}


  	public static void imprimir_Classes(String[][] tab_valor, Node raiz_arvore){
  		for(int i = 0; i < Linhas; i++){
  			Node node = new Node(raiz_arvore);
  			String[] exampleslinha = new String[attrib_glob.size()-2];
  			for(int j = 1;j < attrib_glob.size()-1;j++)
  				exampleslinha[j-1] = tab_valor[i][j];
  			obter_Classe(exampleslinha,node);
  		}
  	}


  	public static void obter_Classe(String[] tab_valor, Node node){
  		if(node.sClasse()){
   			System.out.println(node.getvalor());
  		}
  		else {
  			LinkedList<Node> filhos = node.getfilhos();
  			int atribIndex = attrib_glob.indexOf(node.getatributo())-1;
  			String atributo = node.getatributo();
  			String valor = node.getvalor();

  			while(!filhos.isEmpty()){
  				Node child = new Node(filhos.remove());
   				if(!child.sClasse() && tab_valor[atribIndex].equals(child.getvalor()))
  					obter_Classe(tab_valor,child);
  				else if(child.sClasse() && tab_valor[atribIndex].equals(child.getatributo()))
  					obter_Classe(tab_valor,child);
  			}
  		}
  	}

  	public static void imprimir_tabela(String[][] tab_valor){
  		for(String s: attrib_glob)
  			System.out.printf("%s",s);
  		System.out.println();
  		for(int i = 0; i < Linhas; i++){
  			for(int j = 0;j < attrib_glob.size(); j++)
  				System.out.printf("%s",tab_valor[i][j]);
  			System.out.println();
  		}
  	}
}
