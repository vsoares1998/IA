import java.util.Scanner;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.PriorityQueue;
import java.util.Stack;


class Puzzle {
  public static void Input_Tabuleiro(Tabuleiro t, Scanner stdin){
    for(int i = 0; i < 4; i++){
      for(int j = 0; j < 4; j++){
        t.matrix[i][j] = stdin.nextInt();
        if(t.matrix[i][j] == 0){
          t.x_zero = i;
          t.y_zero = j;
        }
      }
    }
/*
    for(int i = 0; i < 4; i++){
      for(int j = 0; j < 4; j++){
        System.out.print(t.matrix[i][j] + "");
      }
    }
*/
  }

  public static void Valido(Tabuleiro t){
    boolean[] vetor = new boolean[16];
    Arrays.fill(vetor, false);
    for(int i = 0; i < 4; i++){
      for(int j = 0; j < 4; j++){
        if(t.matrix[i][j] <= 15 && t.matrix[i][j] >= 0)
          vetor[t.matrix[i][j]] = true;
      }
    }
    for(int k = 0; k < 16; k++)
      if(vetor[k] != true){
        System.out.println("Erro, tabuleiro inválido");
        System.exit(1);
      }
  }

  public static Boolean Possivel(Tabuleiro Inicial, Tabuleiro Final){
    Boolean result = false;
    int[] Inicial_vetor = new int[16];
    int[] Final_vetor = new int[16];
    int inversoes1 = 0, inversoes2 = 0, k = 0;

    for(int i = 0; i < 4; i++){
      for(int j = 0; j < 4; j++){
        Inicial_vetor[k] = Inicial.matrix[i][j];
        Final_vetor[k] = Final.matrix[i][j];
        k++;
      }
    }

    for(int i = 0; i < 16; i++){
      for(int j = i+1; j < 16; j++){
        if(Inicial_vetor[j]!=0 && Inicial_vetor[i]>Inicial_vetor[j])
            inversoes1++;
        if(Final_vetor[j]!=0 && Final_vetor[i]>Final_vetor[j])
            inversoes2++;
          }
        }
    if(((4-Final.x_zero)%2 == 1) == ((inversoes2%2)==0) == ((4-Inicial.x_zero)%2 == 1) == ((inversoes1%2)==0))
      result = true;

    return result;
  }

  public static Boolean Igual(Tabuleiro t1, Tabuleiro t2){
    for(int i = 0; i <4; i++){
      for(int j = 0; j < 4; j++){
        if(t1.matrix[i][j] != t2.matrix[i][j])
          return false;
      }
    }
    return true;
  }

  public static int ForaLugar(Tabuleiro t1, Tabuleiro t2){
    int total = 0;
    for(int i = 0; i < 4; i++){
      for(int j = 0; j < 4; j++){
        if(t1.matrix[i][j] != t2.matrix[i][j])
          total++;
      }
    }
    return total;
  }

  public static int[] CoordenadasPonto(int n, Tabuleiro t1){
    int[] v = new int[2];
    for(int i = 0; i < 4; i++){
      for(int j = 0; j < 4; j++){
        if(t1.matrix[i][j] == n){
          v[0] = i;
          v[1] = j;
        }
      }
    }
    return v;
  }
  static boolean[] flag = new boolean[4];
  public static void MudaZero(Tabuleiro t, int x, int y, int filho){
    if(x < 4 && x >=0 && y < 4 && y >= 0){
      if(t.x_zero == (x+1))
        t.jogada = "baixo";
      else if(t.x_zero == (x-1))
        t.jogada = "cima";
      else if(t.y_zero == (y+1))
        t.jogada = "direita";
      else
        t.jogada = "esquerda";
      t.matrix[t.x_zero][t.y_zero] = new Integer(t.matrix[x][y]);
      t.matrix[x][y] = 0;
      t.x_zero = x;
      t.y_zero = y;
      flag[filho] = true;
    }
  }

  public static int ManhattanDistance(Tabuleiro Inicial, Tabuleiro Final){
    int dist = 0;
    int[] v = new int[2];

    for(int i = 0; i < 4; i++){
      for(int j = 0; j< 4; j++){
        v = CoordenadasPonto(Inicial.matrix[i][j], Final);
        dist = dist + (Math.abs(v[0] - i) + Math.abs(v[1] - j));
      }
    }
    return dist;
  }


  public static void Print(Tabuleiro obtido,int altura){
    while(obtido!= null){
      System.out.println();
      System.out.println("No de profundidade: "+altura);
      --altura;
      System.out.println("====================\n");
      for(int i=0;i<4;i++){
        System.out.println("*****************");
        System.out.print("|");
        for(int j=0;j<4;j++){
          if(obtido.matrix[i][j]>=0 && obtido.matrix[i][j]<10){
            if(j!=3)
            System.out.print(" " + obtido.matrix[i][j] + " |");
            else
            System.out.print(" " + obtido.matrix[i][j] + " |");
          }

    else{
        if(j!=3)
        System.out.print(" " + obtido.matrix[i][j] + "|");
    else
        System.out.print(" " + obtido.matrix[i][j] + "|");
      }
  }
    System.out.println();
    }
      System.out.println("*****************");
      System.out.println();

    if(obtido.jogada.equals("direita") || obtido.jogada.equals("esquerda"))
      System.out.println("Movimento do espaço em branco para a "+obtido.jogada+" resulta em:" );
    else if(obtido.jogada.equals("null")==false)
      System.out.println("Movimento do espaço em branco para "+obtido.jogada+" resulta em:" );

      obtido = obtido.pai;
}
  }

  //Metodo que verifica se um no ja foi visitado pela funçao de busca
  public static Boolean esta_contido(LinkedList<Node> lista, Tabuleiro t){
      for (Node n : lista)
          if(Igual(t,n.tabuleiro)){
              return true;
            }
      return false;
  }
  public static Boolean Comparador_de_tamanho(LinkedList<Node> lista, Tabuleiro t,int altura_nova){
    for (Node n : lista)
      if(Igual(t,n.tabuleiro)){
        if(altura_nova < n.altura)
          return false;
        else
          return true;
      }
      return false;
  }

  public static LinkedList<Node> CriaDescendentes(int heuristica, Node n, LinkedList<Node> visitados, Tabuleiro Final){

  Tabuleiro[] tabuleiro_array = new Tabuleiro[4];
  LinkedList<Node> descendentes = new LinkedList<Node>();
  int[] heuristica_array = new int[4];

  for(int i=0;i<4;i++){
      tabuleiro_array[i] = new Tabuleiro(n.tabuleiro);
      flag[i] = false;
  }
  MudaZero(tabuleiro_array[0],(tabuleiro_array[0].x_zero),(tabuleiro_array[0].y_zero-1), 0);

  MudaZero(tabuleiro_array[1],(tabuleiro_array[1].x_zero),(tabuleiro_array[1].y_zero+1), 1);

  MudaZero(tabuleiro_array[2],(tabuleiro_array[2].x_zero-1),(tabuleiro_array[2].y_zero), 2);
	MudaZero(tabuleiro_array[3],(tabuleiro_array[3].x_zero+1),(tabuleiro_array[3].y_zero), 3);

  if(heuristica==1){ //Busca Gulosa com a heuristica "Numero total de peças fora do lugar"
    heuristica_array[0] = ForaLugar(tabuleiro_array[0],Final);
    heuristica_array[1] = ForaLugar(tabuleiro_array[1],Final);
    heuristica_array[2] = ForaLugar(tabuleiro_array[2],Final);
    heuristica_array[3] = ForaLugar(tabuleiro_array[3],Final);

    for(int i=0;i<4;i++){
      if(esta_contido(visitados,tabuleiro_array[i])==false)
        descendentes.add(new Node(n.altura+1,heuristica_array[i],tabuleiro_array[i]));
      }
  }

  if(heuristica==2){ //Busca A* com a heuristica "Numero total de peças fora do lugar"
    heuristica_array[0] = (n.altura+1) + ForaLugar(tabuleiro_array[0],Final);
    heuristica_array[1] = (n.altura+1) + ForaLugar(tabuleiro_array[1],Final);
    heuristica_array[2] = (n.altura+1) + ForaLugar(tabuleiro_array[2],Final);
    heuristica_array[3] = (n.altura+1) + ForaLugar(tabuleiro_array[3],Final);

  for(int i=0;i<4;i++){
    if(esta_contido(visitados,tabuleiro_array[i])==false)
      descendentes.add(new Node(n.altura+1,heuristica_array[i],tabuleiro_array[i]));
      }
    }

  if(heuristica==3){ //Busca Gulosa com a heuristica "Manhattan Distance"
    heuristica_array[0] = ManhattanDistance(tabuleiro_array[0],Final);
    heuristica_array[1] = ManhattanDistance(tabuleiro_array[1],Final);
    heuristica_array[2] = ManhattanDistance(tabuleiro_array[2],Final);
    heuristica_array[3] = ManhattanDistance(tabuleiro_array[3],Final);

  for(int i=0;i<4;i++){
    if(esta_contido(visitados,tabuleiro_array[i])==false)
      descendentes.add(new Node(n.altura+1,heuristica_array[i],tabuleiro_array[i]));
      }
    }


    if(heuristica==4){ //Busca A* com a heuristica "Manhattan Distance"
      heuristica_array[0] = (n.altura+1) + ManhattanDistance(tabuleiro_array[0],Final);
      heuristica_array[1] = (n.altura+1) + ManhattanDistance(tabuleiro_array[1],Final);
      heuristica_array[2] = (n.altura+1) + ManhattanDistance(tabuleiro_array[2],Final);
      heuristica_array[3] = (n.altura+1) + ManhattanDistance(tabuleiro_array[3],Final);

  for(int i=0;i<4;i++){
    if(esta_contido(visitados,tabuleiro_array[i])==false)
      descendentes.add(new Node(n.altura+1,heuristica_array[i],tabuleiro_array[i]));
    }
  }

  if(heuristica==5){ //Busca BFS
    for(int i=0;i<4;i++){
    	if(flag[i] == true){
      		if(esta_contido(visitados,tabuleiro_array[i])==false)
        		descendentes.add(new Node(n.altura+1,0,tabuleiro_array[i]));
        }
      }
    }

  if(heuristica==6){  //Busca IDFS
    for(int i=0;i<4;i++){
      if(Comparador_de_tamanho(visitados,tabuleiro_array[i],(n.altura+1))==false)
        descendentes.add(new Node(n.altura+1,0,tabuleiro_array[i]));
      }
    }

    return descendentes;
  }


public static void DFSearchAlgorithm(Tabuleiro Inicial,Tabuleiro Final,int heuristica){
  long tempo_inicial = System.currentTimeMillis();
  Stack<Node> queue = new Stack<Node>();
  LinkedList<Node> descendentes = new LinkedList<Node>();
  LinkedList<Node> visitados = new LinkedList<Node>();
  int num_gerados=0;
  int num_visitados=0;
  queue.add(new Node(0,0,Inicial));

  while(queue.isEmpty()!=true){
      Node n = queue.pop();
      if(!esta_contido(visitados, n.tabuleiro))
      	visitados.add(n);
      if(Igual(n.tabuleiro,Final)==true){
          System.out.println();
          System.out.println("Soluçao encontrada em " + n.altura + " passos");
          System.out.println("Numero de nos gerados: " + num_gerados);
          System.out.println("Numero de nos visitados: " + num_visitados);
          System.out.println("Quantidade de tempo gasto: " + (double)(System.currentTimeMillis() - tempo_inicial) / 1000.0 + " segundos.");
          Print(n.tabuleiro,n.altura);
          return;
      }
        if(((double)(System.currentTimeMillis() - tempo_inicial) / 1000.0) >= 60){ //limite de 1 min para encontrar solução
          System.out.println();
          System.out.println("Soluçao nao encontrada em menos de 1 minuto");
          System.out.println("Numero de nos gerados: " + num_gerados);
          System.out.println("Numero de nos visitados: " + num_visitados);
          return;
        }


        //}
        //else{
          descendentes = CriaDescendentes(heuristica,n,visitados,Final);
          while(descendentes.isEmpty() != true) {
              queue.push(descendentes.removeFirst());
              num_gerados++;
          }
        //}
      }
  System.out.println("Soluçao nao encontrada\n");
}

public static void BFSearchAlgorithm(Tabuleiro Inicial,Tabuleiro Final,int heuristica){
  long tempo_inicial = System.currentTimeMillis();
  LinkedList<Node> queue = new LinkedList<Node>();
  LinkedList<Node> descendentes = new LinkedList<Node>();
  LinkedList<Node> visitados = new LinkedList<Node>();
  int num_gerados=0;
  int num_visitados=0;
  queue.add(new Node(0,0,Inicial));
  while(queue.isEmpty()!=true){
    Node n = queue.poll();
    visitados.add(n);
    num_visitados++;
    if(((double)(System.currentTimeMillis() - tempo_inicial) / 1000.0) >= 60){ //limite de 1 min para encontrar solução
      System.out.println();
      System.out.println("Soluçao nao encontrada em menos de 1 minuto");
      System.out.println("Numero de nos gerados: " + num_gerados);
      System.out.println("Numero de nos visitados: " + num_visitados);
      return;
    }
    if(Igual(n.tabuleiro,Final)==true){
      System.out.println();
      System.out.println("Soluçao encontrada em " + n.altura + " passos");
      System.out.println("Numero de nos gerados: " + num_gerados);
      System.out.println("Numero de nos visitados: " + num_visitados);
      System.out.println("Quantidade de tempo gasto: " + (double)(System.currentTimeMillis() - tempo_inicial) / 1000.0 + " segundos.");
      Print(n.tabuleiro,n.altura);
      return;
    }
    else{
      descendentes = CriaDescendentes(heuristica,n,visitados,Final);
      while(descendentes.isEmpty()!=true){
        queue.add(descendentes.poll());
        num_gerados++;
      }
    }
  }
  System.out.println("Soluçao nao encontrada\n");
}

public static void IDFSSearchAlgorithm(Tabuleiro Inicial,Tabuleiro Final,int heuristica){
  int limite = 0;
  long tempo_inicial = System.currentTimeMillis();
  LinkedList<Node> queue = new LinkedList<Node>();
  LinkedList<Node> descendentes = new LinkedList<Node>();
  LinkedList<Node> visitados = new LinkedList<Node>();
  int num_gerados=0;
  int num_visitados=0;
  queue.add(new Node(0,0,Inicial));
  while(true){
    while(queue.isEmpty()!=true){
      Node n = queue.poll();
      if(n.altura <= limite){
        visitados.add(n);
        num_visitados++;
        if(((double)(System.currentTimeMillis() - tempo_inicial) / 1000.0) >= 60){ //limite de 1 min para encontrar solução
          System.out.println();
          System.out.println("Soluçao nao encontrada em menos de 1 minuto");
          System.out.println("Numero de nos gerados: " + num_gerados);
          System.out.println("Numero de nos visitados: " + num_visitados);
          return;
        }
        if(Igual(n.tabuleiro,Final) == true){
          System.out.println();
          System.out.println("Soluçao encontrada em " + n.altura + " passos");
          System.out.println("Numero de nos gerados: " + num_gerados);
          System.out.println("Numero de nos visitados: " + num_visitados);
          System.out.println("Quantidade de tempo gasto: " + (double)(System.currentTimeMillis() - tempo_inicial) / 1000.0 + " segundos.");
          Print(n.tabuleiro,n.altura);
          return;
        }
        else{
          descendentes = CriaDescendentes(heuristica,n,visitados,Final);
          while(descendentes.isEmpty() != true){
            queue.addFirst(descendentes.poll());
            num_gerados++;
          }
        }
      }
    }
    queue.clear();
    queue.add(new Node(0,0,Inicial));
    visitados.clear();
    limite++;
  }
}

public static void GulosaSearchAlgorithm(Tabuleiro Inicial,Tabuleiro Final,int heuristica){
  long tempo_inicial = System.currentTimeMillis();
  PriorityQueue<Node> queue = new PriorityQueue<Node>();
  LinkedList<Node> descendentes = new LinkedList<Node>();
  LinkedList<Node> visitados = new LinkedList<Node>();
  int num_gerados=0;
  int num_visitados=0;
  queue.add(new Node(0,0,Inicial));
  while(queue.isEmpty()!=true){
    Node n = queue.poll();
    visitados.add(n);
    num_visitados++;
    if(Igual(n.tabuleiro,Final)==true){
      System.out.println();
      System.out.println("Soluçao encontrada em " + n.altura + " passos");
      System.out.println("Numero de nos gerados: " + num_gerados);
      System.out.println("Numero de nos visitados: " + num_visitados);
      System.out.println("Quantidade de tempo gasto: " + (double)(System.currentTimeMillis() - tempo_inicial) / 1000.0 + " segundos.");
      Print(n.tabuleiro,n.altura);
      return;
    }
    else{
        descendentes = CriaDescendentes(heuristica,n,visitados,Final);
        while(descendentes.isEmpty()!=true){
          queue.add(descendentes.poll());
          num_gerados++;
        }
    }
  }
  System.out.println("Soluçao nao encontrada\n");
}

public static void ASTARSearchAlgorithm(Tabuleiro Inicial,Tabuleiro Final,int heuristica){
  long tempo_inicial = System.currentTimeMillis();
  PriorityQueue<Node> queue = new PriorityQueue<Node>();
  LinkedList<Node> descendentes = new LinkedList<Node>();
  LinkedList<Node> visitados = new LinkedList<Node>();
  int num_gerados=0;
  int num_visitados=0;
  queue.add(new Node(0,0,Inicial));
  while(queue.isEmpty()!=true){
    Node n = queue.poll();
    visitados.add(n);
    num_visitados++;
    if(Igual(n.tabuleiro,Final)==true){
      System.out.println();
      System.out.println("Soluçao encontrada em " + n.altura + " passos");
      System.out.println("Numero de nos gerados: " + num_gerados);
      System.out.println("Numero de nos visitados: " + num_visitados);
      System.out.println("Quantidade de tempo gasto: " + (double)(System.currentTimeMillis() - tempo_inicial) / 1000.0 + " segundos.");
      Print(n.tabuleiro,n.altura);
      return;
    }
    else{
      descendentes = CriaDescendentes(heuristica,n,visitados,Final);
      while(descendentes.isEmpty()!=true){
        queue.add(descendentes.poll());
        num_gerados++;
      }
    }
  }
  System.out.println("Soluçao nao encontrada\n");
}

public static void Menu(){
  System.out.println("Introduza a busca pretendida.");
  System.out.println("1 --> DFS");
  System.out.println("2 --> BFS");
  System.out.println("3 --> IDFS");
  System.out.println("4 --> GULOSA");
  System.out.println("5 --> A*");
}

public static void main(String[] args){
  Scanner stdin = new Scanner(System.in);
  Tabuleiro Inicial = new Tabuleiro();
  Tabuleiro Final = new Tabuleiro();
  Boolean possible;
  int n;

  System.out.println("Introduza o tabuleiro inicial:");
  Input_Tabuleiro(Inicial,stdin);
  Valido(Inicial);
  System.out.println("Introduza o tabuleiro final:");
  Input_Tabuleiro(Final,stdin);
  Valido(Final);
  possible = Possivel(Inicial,Final);
  if(possible==false){
      System.out.println("Problema sem solução\n");
      System.exit(1);
  }

  System.out.println();
  Menu();

  int busca = stdin.nextInt();
  switch(busca){
    case 1:
      DFSearchAlgorithm(Inicial,Final,5);
      break;
    case 2:
      BFSearchAlgorithm(Inicial,Final,5);
      break;
    case 3:
      IDFSSearchAlgorithm(Inicial,Final,6);
      break;
    case 4: //colocar os 2 casos
      System.out.println("Introduza a heuristica que pretende utilizar?");
      System.out.println("1 --> ManhattanDistance");
      System.out.println("2 --> Nº Peças Fora do Lugar");
      n = stdin.nextInt();
      if(n == 1)
        GulosaSearchAlgorithm(Inicial, Final,3);
      else if(n == 2)
        GulosaSearchAlgorithm(Inicial, Final, 1);
      else{
        System.out.println("Opção introduzida não é válida.");
        Menu();
      }
      break;
    case 5:  //colocar os 2 casos
      System.out.println("Introduza a heuristica que pretende utilizar?");
      System.out.println("1 --> ManhattanDistance");
      System.out.println("2 --> Nº Peças Fora do Lugar");
      n = stdin.nextInt();
      if(n == 1)
        ASTARSearchAlgorithm(Inicial, Final, 4);
      else if(n == 2)
        ASTARSearchAlgorithm(Inicial, Final, 2);
      else{
        System.out.println("Opção introduzida não é válida.");
        Menu();
      }
      break;
    default:
      System.out.println("Opção introduzida não é válida.");
      Menu();
  }

}

}
