class Tabuleiro {
  public int[][] matrix;
  public int x_zero,y_zero;
  public Tabuleiro pai;
  public String jogada;

  public Tabuleiro() {
    Tabuleiro t1 = this;  // criar tabuleiro
    t1.pai = null;
    t1.matrix = new int[4][4];
    for(int i = 0; i < 4; i++){
      for(int j = 0; j < 4; j++){
        t1.matrix[i][j] = 0;  //inicializar a matriz com valores 0
      }
    }
    t1.x_zero = 0;
    t1.y_zero = 0;
    t1.jogada = "null";
  }

  public Tabuleiro(Tabuleiro t2) {
    this.matrix = new int[4][4];
    Tabuleiro t1 = this;  // criar tabuleiro

    for(int i = 0; i < 4; i++){
      for(int j = 0; j < 4; j++){
        t1.matrix[i][j] = new Integer(t2.matrix[i][j]);  //inicializar a matriz com valores dados
      }
    }
    t1.pai = t2;
    t1.x_zero = new Integer(t2.x_zero);
    t1.y_zero = new Integer(t2.y_zero);
    t1.jogada = "null";
  }
}
