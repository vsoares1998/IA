class Node implements Comparable<Node> {
    public int altura;
    public int heuristica;
    public Tabuleiro tabuleiro;

    //Costrutor do Node
    Node(int altura,int heuristica, Tabuleiro b) {
	     this.altura = altura;
	     this.tabuleiro = b;
	     this.heuristica = heuristica;
    }

    //Possiblita a comparação de Nodes com base na heuristica
    public int compareTo(Node p) {
	     if(this.heuristica < p.heuristica)
	      return -1;
	     else
	        return 1;
    }

}
