public class TrainingData {

    float[] data;
    float[] expectedOutput;

    public TrainingData(float[] data, float[] expectedOutput) {
        this.data = data;
        this.expectedOutput = expectedOutput;
    }

}
