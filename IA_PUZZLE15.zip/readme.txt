(A realizar no diretorio que contém os ficheiros do trabalho)

Executar:

"java Puzzle15 "Busca""   exemplo : "java Puzzle15 BFS"

Tipos de Busca:
"DFS" - Busca em Profundidade
"BFS" - Busca em Largura
"BILP" - Busca Iterativa Limitada em Profundidade
"A*" - Busca A estrela
"Gulosa" - Busca Gulosa

O programa foi compilado com um jdk na versão 1.8.0_151 e num Ubuntu 16.04 LTS. Utiliza as seguintes classes do package java.util:

java.util.Arrays;
java.util.Scanner;
java.util.LinkedList;
java.util.PriorityQueue;

Tomei a liberdade de não utilizar acentuação em nenhuma parte do programa para evitar que codificações de acentuação gráfica diferentes interfiram na execução do programa.


